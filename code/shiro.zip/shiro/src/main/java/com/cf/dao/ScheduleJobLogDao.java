package com.cf.dao;

import com.cf.entity.ScheduleJobLogEntity;

/**
 * 定时任务日志
 * 
 */
public interface ScheduleJobLogDao extends BaseDao<ScheduleJobLogEntity> {
	
}
