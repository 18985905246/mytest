package com.cf.shiro.service;

import java.util.Date;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.session.Session;

public class ShiroService {

	@RequiresRoles({"admin"})
	public void testMethod(){
		Session session = SecurityUtils.getSubject().getSession();
		Object obj = session.getAttribute("key1");
		System.out.println("----------------->session:" + obj);
		
		System.out.println("----------------->testMethod:" + new Date());
	}
}
