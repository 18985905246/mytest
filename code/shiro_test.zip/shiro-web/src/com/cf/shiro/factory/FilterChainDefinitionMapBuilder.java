package com.cf.shiro.factory;

import java.util.LinkedHashMap;

public class FilterChainDefinitionMapBuilder {
	
	public LinkedHashMap<String, String> buildFilterChainDefinitionMap() {
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
//        /login.jsp = anon
//        /shiro/login = anon
//        /shiro/logout = logout
//        /user.jsp = roles[user]
//        /admin.jsp = roles[admin]
//        /** = authc
		// TODO �����ݿ⣬�����������ط�ȥ��ȡ
		map.put("/login.jsp", "anon");
		map.put("/shiro/login", "anon");
		map.put("/shiro/logout", "logout");
		map.put("/list.jsp", "user");
		map.put("/user.jsp", "authc,roles[user]");
		map.put("/admin.jsp", "authc,roles[admin]");
		map.put("/**", "authc");
		
		return map;
	}

}
